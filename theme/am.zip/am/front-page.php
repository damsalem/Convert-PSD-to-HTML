<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package A&M
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<!-- Start homepage content -->

        <div class="fullscreen-bg">
            <video loop muted autoplay class="fullscreen-bg__video" poster="<?php echo(get_template_directory_uri()); ?>/images/hero.png">
                <source src="<?php echo(get_template_directory_uri()); ?>/assets/overlay.webm" type="video/webm">
                <source src="<?php echo(get_template_directory_uri()); ?>/assets/overlay.mp4" type="video/mp4">
                <source src="<?php echo(get_template_directory_uri()); ?>/assets/overlay.mov" type="video/mov">
            </video>
            <div class="purple-circle">
                <h2>16-18 May 2018</h2>
                <h3>| &nbsp;Tax Trends Today</h3>
            </div>
        </div>

    <div class="wrapper pt-3" id="about">
        <section class="about">
            <h2>ABOUT ALVARAZ & MARSAL TAXAND</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam fermentum vitae nibh nec ornare. 
                Nunc id laoreet leo, in varius tortor. Nam elementum velit blandit massa rhoncus, sed fringilla 
                est molestie. Praesent pellentesque imperdiet massa, non ornare lectus luctus ac. Morbi bibendum 
                facilisis commodo. Praesent ultrices convallis auctor. Pellentesque maximus metus nec nunc tempus 
                mattis. Maecenas ornare libero sit amet orci lacinia, at porta arcu dignissim. In condimentum 
                aliquam pretium. Nulla et lacinia ipsum. Nunc blandit nibh id tristique sagittis. Aenean 
                tincidunt augue commodo viverra efficitur.
            </p>
            <p>
                Vivamus facilisis leo id justo tempus, a elementum purus aliquam. Proin ullamcorper lorem vel 
                nulla vulputate, in egestas mauris consectetur. Donec vel consectetur enim, non vulputate ipsum. 
                Duis ac suscipit dui. Praesent dapibus vitae est et malesuada. Aenean et pellentesque metus, a 
                congue leo. In sit amet urna cursus, aliquam libero nec, interdum ex. Nunc eget rutrum ipsum. 
                Cras sagittis elit ac auctor vehicula.
            </p>
        </section>
    </div>

        <div id="services-banner">
            <img src="<?php echo(get_template_directory_uri()); ?>/images/services-wheel.png" alt="Services Banner">
            <div class="center-left-text">
                <h2>What We Do</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam fermentum vitae nibh nec ornare. 
                    Nunc id laoreet leo, in varius tortor. Nam elementum velit blandit massa rhoncus, sed fringilla 
                    est molestie. Praesent pellentesque imperdiet massa, non ornare lectus luctus ac. Morbi bibendum 
                    facilisis commodo. Praesent ultrices convallis auctor. Pellentesque maximus metus nec nunc tempus 
                    mattis. Maecenas ornare libero sit amet orci lacinia, at porta arcu dignissim. In condimentum 
                    aliquam pretium. Nulla et lacinia ipsum. Nunc blandit nibh id tristique sagittis. Aenean 
                    tincidunt augue commodo viverra efficitur.
                </p>
            </div>
        </div>

    <!-- End Homepage content -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
