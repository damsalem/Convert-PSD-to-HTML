<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package A&M
 */

?>

	</div><!-- #content -->

	<footer>
		<div class="container">

		<div class="row">
                <div class="col-5 offset-1 col-sm-5 offset-sm-1 col-md-3 offset-md-0 col-xl-2">
                    <a href="#"><img src="<?php echo(get_template_directory_uri()); ?>/images/footer-a&m.png" alt="logo"></a>
                </div>
                <div class="col-6 col-sm-6 col-md-3 col-xl-5">
                    <br />
                    <ul>
                        <li>600 Madison Avenue</li>
                        <li>8th Floor</li>
                        <li>New York, New York, 10022</li>
                    </ul>
                </div>
                <div class="col-10 offset-4 col-sm-4 offset-sm-4 col-md-3 offset-md-3 col-xl-2 offset-xl-2" id="follow">
                    <br />
                    <p>&nbsp; Follow us on:</p>
                    <ul class="social">
                        <li><a href="https://linkedin.com"><img src="<?php echo(get_template_directory_uri()); ?>/images/footer-follow-linkedin.png" alt="linkedin"></a></li>
                        <li><a href="https://facebook.com"><img src="<?php echo(get_template_directory_uri()); ?>/images/footer-follow-facebook.png" alt="facebook"></a></li>
                        <li><a href="https://twitter.com"><img src="<?php echo(get_template_directory_uri()); ?>/images/footer-follow-twitter.png" alt="twitter"></a></li>
                        <li><a href="https://linkedin.com"><img src="<?php echo(get_template_directory_uri()); ?>/images/footer-follow-youtube.png" alt="youtube"></a></li>
                    </ul>
                </div>
                <div class="col-11 offset-1 offset-md-0">
                    <p class="copyright">	&copy; Copyright 2017, Alvarez & Marsal Holdings, LLC. All Rights Reserved</p>
                </div>
            </div>
		</div><!-- .container -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
